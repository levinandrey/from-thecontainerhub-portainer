Setup the session parameters as described above.
